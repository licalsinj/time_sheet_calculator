# Time Sheet Calculator

## Overview
This desktop application calculates weekly hours, remaining time to reach 40, and an estimated Friday clock-out time.

## Highlights
- Fast entry with automatic time normalization
- Weekly totals with quarter-hour rounding
- Friday clock-out estimate based on current week hours

## Formatting Examples
This line uses **bold** for emphasis.
This line uses *italics* for emphasis.
